(function () {
    'use strict';

    angular.module('folderBrowse').controller('folderBrowseCtrl', ['$ionicPlatform','$state','$cordovaFile','$cordovaDialogs', folderBrowseCtrl]);

    function folderBrowseCtrl($ionicPlatform, $state, $cordovaFile, $cordovaDialogs) {
       
        var vm = this;

        vm.files =[]; 

        vm.parentDirectory = null;
        vm.root = null;
        vm.pathSelected = "";

       
        vm.onBackButtonClick = function(){

            vm.getContents(vm.parentDirectory);

        };

        vm.selectItem = function(url){

          vm.pathSelected = url;
        }


        $ionicPlatform.ready(function() { 

         vm.getContents("file:///storage/");      
           
        });

      

        vm.getContents= function(path)
        { 
            vm.CurrentFolder = path;
            $cordovaFile.listFolder(path)
              .then(function (success) 
              {
                  var result = _.sortBy(success,function(o) { return o.isFile == true; });
                  vm.files = result;
                  $cordovaFile.getParentDirectory(path)
                  .then(function (parent) {  
                        vm.parentDirectory = parent.nativeURL;    
                  }, function (error) {
                      $cordovaDialogs.alert(JSON.stringify(error), "error!!", "ok");
                  });


              }, function (error) {
                  $cordovaDialogs.alert(JSON.stringify(error), "error!!", "ok");
              });
        };      
              
    };
})();